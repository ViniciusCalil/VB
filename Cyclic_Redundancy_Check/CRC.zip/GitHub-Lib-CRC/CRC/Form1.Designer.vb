﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TB_inp = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TB_crc = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TB_poly = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TB_crcsize = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TB_InitRmnd = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TB_finalXOr = New System.Windows.Forms.TextBox()
        Me.TB_ret = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.CB_RevOut = New System.Windows.Forms.CheckBox()
        Me.CB_RevInp = New System.Windows.Forms.CheckBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.CB_StrgTpASCII = New System.Windows.Forms.CheckBox()
        Me.CB_StrgTpHex = New System.Windows.Forms.CheckBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.NUD_BitOffset = New System.Windows.Forms.NumericUpDown()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.CB_StrmOrByte = New System.Windows.Forms.CheckBox()
        Me.CB_StrmOrBit = New System.Windows.Forms.CheckBox()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        CType(Me.NUD_BitOffset, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TB_inp
        '
        Me.TB_inp.Location = New System.Drawing.Point(13, 47)
        Me.TB_inp.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TB_inp.MaxLength = 1024
        Me.TB_inp.Multiline = True
        Me.TB_inp.Name = "TB_inp"
        Me.TB_inp.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TB_inp.Size = New System.Drawing.Size(739, 77)
        Me.TB_inp.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(16, 20)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(80, 17)
        Me.Label1.TabIndex = 111
        Me.Label1.Text = "Input String"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(183, 533)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(175, 17)
        Me.Label2.TabIndex = 111
        Me.Label2.Text = "CRC Output (hexadecimal)"
        '
        'TB_crc
        '
        Me.TB_crc.Location = New System.Drawing.Point(81, 559)
        Me.TB_crc.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TB_crc.Name = "TB_crc"
        Me.TB_crc.Size = New System.Drawing.Size(357, 22)
        Me.TB_crc.TabIndex = 8
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(331, 486)
        Me.Button1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(113, 37)
        Me.Button1.TabIndex = 7
        Me.Button1.Text = "Calculate"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(392, 235)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(168, 17)
        Me.Label3.TabIndex = 111
        Me.Label3.Text = "Polynomial (hexadecimal)"
        '
        'TB_poly
        '
        Me.TB_poly.Location = New System.Drawing.Point(389, 265)
        Me.TB_poly.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TB_poly.MaxLength = 1024
        Me.TB_poly.Name = "TB_poly"
        Me.TB_poly.Size = New System.Drawing.Size(361, 22)
        Me.TB_poly.TabIndex = 2
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(20, 235)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(201, 17)
        Me.Label4.TabIndex = 111
        Me.Label4.Text = "CRC Size (decimal: 1 up to 64)"
        '
        'TB_crcsize
        '
        Me.TB_crcsize.Location = New System.Drawing.Point(17, 265)
        Me.TB_crcsize.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TB_crcsize.MaxLength = 1024
        Me.TB_crcsize.Name = "TB_crcsize"
        Me.TB_crcsize.Size = New System.Drawing.Size(131, 22)
        Me.TB_crcsize.TabIndex = 1
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(20, 305)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(197, 17)
        Me.Label5.TabIndex = 111
        Me.Label5.Text = "Initial Reminder (hexadecimal)"
        '
        'TB_InitRmnd
        '
        Me.TB_InitRmnd.Location = New System.Drawing.Point(12, 335)
        Me.TB_InitRmnd.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TB_InitRmnd.MaxLength = 1024
        Me.TB_InitRmnd.Name = "TB_InitRmnd"
        Me.TB_InitRmnd.Size = New System.Drawing.Size(361, 22)
        Me.TB_InitRmnd.TabIndex = 3
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(400, 305)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(204, 17)
        Me.Label6.TabIndex = 111
        Me.Label6.Text = "Final XOR Value (hexadecimal)"
        '
        'TB_finalXOr
        '
        Me.TB_finalXOr.Location = New System.Drawing.Point(389, 335)
        Me.TB_finalXOr.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TB_finalXOr.MaxLength = 1024
        Me.TB_finalXOr.Name = "TB_finalXOr"
        Me.TB_finalXOr.Size = New System.Drawing.Size(361, 22)
        Me.TB_finalXOr.TabIndex = 4
        '
        'TB_ret
        '
        Me.TB_ret.Location = New System.Drawing.Point(484, 559)
        Me.TB_ret.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TB_ret.Name = "TB_ret"
        Me.TB_ret.Size = New System.Drawing.Size(109, 22)
        Me.TB_ret.TabIndex = 9
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(511, 533)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(51, 17)
        Me.Label7.TabIndex = 111
        Me.Label7.Text = "Return"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.CB_RevOut)
        Me.GroupBox1.Controls.Add(Me.CB_RevInp)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 378)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox1.Size = New System.Drawing.Size(740, 58)
        Me.GroupBox1.TabIndex = 113
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Reflected"
        '
        'CB_RevOut
        '
        Me.CB_RevOut.AutoSize = True
        Me.CB_RevOut.Location = New System.Drawing.Point(397, 27)
        Me.CB_RevOut.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.CB_RevOut.Name = "CB_RevOut"
        Me.CB_RevOut.Size = New System.Drawing.Size(73, 21)
        Me.CB_RevOut.TabIndex = 6
        Me.CB_RevOut.Text = "Output"
        Me.CB_RevOut.UseVisualStyleBackColor = True
        '
        'CB_RevInp
        '
        Me.CB_RevInp.AutoSize = True
        Me.CB_RevInp.Location = New System.Drawing.Point(20, 27)
        Me.CB_RevInp.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.CB_RevInp.Name = "CB_RevInp"
        Me.CB_RevInp.Size = New System.Drawing.Size(191, 21)
        Me.CB_RevInp.TabIndex = 5
        Me.CB_RevInp.Text = "Input String (inside bytes)"
        Me.CB_RevInp.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.CB_StrgTpASCII)
        Me.GroupBox2.Controls.Add(Me.CB_StrgTpHex)
        Me.GroupBox2.Location = New System.Drawing.Point(16, 134)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox2.Size = New System.Drawing.Size(356, 84)
        Me.GroupBox2.TabIndex = 114
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "String Type"
        '
        'CB_StrgTpASCII
        '
        Me.CB_StrgTpASCII.AutoSize = True
        Me.CB_StrgTpASCII.Location = New System.Drawing.Point(197, 38)
        Me.CB_StrgTpASCII.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.CB_StrgTpASCII.Name = "CB_StrgTpASCII"
        Me.CB_StrgTpASCII.Size = New System.Drawing.Size(129, 21)
        Me.CB_StrgTpASCII.TabIndex = 1
        Me.CB_StrgTpASCII.Text = "ASCII Character"
        Me.CB_StrgTpASCII.UseVisualStyleBackColor = True
        '
        'CB_StrgTpHex
        '
        Me.CB_StrgTpHex.AutoSize = True
        Me.CB_StrgTpHex.Location = New System.Drawing.Point(20, 38)
        Me.CB_StrgTpHex.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.CB_StrgTpHex.Name = "CB_StrgTpHex"
        Me.CB_StrgTpHex.Size = New System.Drawing.Size(149, 21)
        Me.CB_StrgTpHex.TabIndex = 0
        Me.CB_StrgTpHex.Text = "Hexadecimal Digits"
        Me.CB_StrgTpHex.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.NUD_BitOffset)
        Me.GroupBox3.Controls.Add(Me.Label8)
        Me.GroupBox3.Controls.Add(Me.CB_StrmOrByte)
        Me.GroupBox3.Controls.Add(Me.CB_StrmOrBit)
        Me.GroupBox3.Location = New System.Drawing.Point(389, 134)
        Me.GroupBox3.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox3.Size = New System.Drawing.Size(363, 84)
        Me.GroupBox3.TabIndex = 115
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Stream Orietation"
        '
        'NUD_BitOffset
        '
        Me.NUD_BitOffset.Location = New System.Drawing.Point(76, 53)
        Me.NUD_BitOffset.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.NUD_BitOffset.Name = "NUD_BitOffset"
        Me.NUD_BitOffset.Size = New System.Drawing.Size(113, 22)
        Me.NUD_BitOffset.TabIndex = 116
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(25, 55)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(50, 17)
        Me.Label8.TabIndex = 117
        Me.Label8.Text = "Offset:"
        '
        'CB_StrmOrByte
        '
        Me.CB_StrmOrByte.AutoSize = True
        Me.CB_StrmOrByte.Location = New System.Drawing.Point(217, 23)
        Me.CB_StrmOrByte.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.CB_StrmOrByte.Name = "CB_StrmOrByte"
        Me.CB_StrmOrByte.Size = New System.Drawing.Size(122, 21)
        Me.CB_StrmOrByte.TabIndex = 1
        Me.CB_StrmOrByte.Text = "BYTE oriented"
        Me.CB_StrmOrByte.UseVisualStyleBackColor = True
        '
        'CB_StrmOrBit
        '
        Me.CB_StrmOrBit.AutoSize = True
        Me.CB_StrmOrBit.Location = New System.Drawing.Point(27, 23)
        Me.CB_StrmOrBit.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.CB_StrmOrBit.Name = "CB_StrmOrBit"
        Me.CB_StrmOrBit.Size = New System.Drawing.Size(102, 21)
        Me.CB_StrmOrBit.TabIndex = 0
        Me.CB_StrmOrBit.Text = "Bit oriented"
        Me.CB_StrmOrBit.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(768, 615)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.TB_ret)
        Me.Controls.Add(Me.TB_finalXOr)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.TB_InitRmnd)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.TB_crcsize)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.TB_poly)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.TB_crc)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TB_inp)
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        CType(Me.NUD_BitOffset, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents TB_inp As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents TB_crc As TextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents TB_poly As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents TB_crcsize As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents TB_InitRmnd As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents TB_finalXOr As TextBox
    Friend WithEvents TB_ret As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents CB_RevOut As CheckBox
    Friend WithEvents CB_RevInp As CheckBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents CB_StrgTpASCII As CheckBox
    Friend WithEvents CB_StrgTpHex As CheckBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents CB_StrmOrByte As CheckBox
    Friend WithEvents CB_StrmOrBit As CheckBox
    Friend WithEvents Label8 As Label
    Friend WithEvents NUD_BitOffset As NumericUpDown
End Class
