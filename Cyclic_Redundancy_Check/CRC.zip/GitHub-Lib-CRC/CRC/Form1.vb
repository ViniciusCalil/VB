﻿Imports System.Security.Cryptography

Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        TB_crcsize.Text = "8"        ' CRC-8/CDMA2000 Stardard
        TB_poly.Text = "9B"          ' CRC-8/CDMA2000 Stardard
        TB_InitRmnd.Text = "FF"      ' CRC-8/CDMA2000 Stardard
        TB_finalXOr.Text = "00"      ' CRC-8/CDMA2000 Stardard
        CB_StrgTpHex.Checked = True
        CB_StrmOrBit.Checked = False
        CB_StrmOrByte.Checked = True
        NUD_BitOffset.Enabled = False

        '--- Create the ToolTip 
        Dim CRC_tooltip As New ToolTip()

        '--- Set up the delays for the ToolTip.
        CRC_tooltip.AutoPopDelay = 20000   ' Gets or sets the period of time the ToolTip remains visible if the pointer is stationary on a control with specified ToolTip text. 
        CRC_tooltip.InitialDelay = 1000    ' Gets or sets the time that passes before the ToolTip appears.
        CRC_tooltip.ReshowDelay = 750      ' Gets or sets the length of time that must transpire before subsequent ToolTip windows appear as the pointer moves from one control to another.
        ' CRC_tooltip.ShowAlways = True   ' Force the ToolTip text to be displayed whether Or Not the form Is active.

        '--- Set up the ToolTip text for the Form components.
        CRC_tooltip.SetToolTip(Me.TB_inp, "Enter the string (of ASCII characters or Hexadecimal values) to calculate its CRC.")
        CRC_tooltip.SetToolTip(Me.CB_StrgTpASCII, "Check this Box if the text supplied to ""Input String"" field must be read as ASCII characters instead of Hexadecimal values.")
        CRC_tooltip.SetToolTip(Me.CB_StrgTpHex, "Check this Box if the text supplied to ""Input String"" field must be read as ASCII characters instead of Hexadecimal values.")
        CRC_tooltip.SetToolTip(Me.CB_StrmOrBit, "Check this Box if the text supplied to ""Input String"" field must be read as bit stream (allowing stream size that are not multiple of 8 bits).")
        CRC_tooltip.SetToolTip(Me.CB_StrmOrByte, "Check this Box if the text supplied to ""Input String"" field must be read as Byte stream (allowing stream size that are only multiple of 8 bits).")
        CRC_tooltip.SetToolTip(Me.NUD_BitOffset, "Select the amount of bits, from the beginning of the ""Input String"" that will be ignored (as if they were not supplied).")
        CRC_tooltip.SetToolTip(Me.TB_crcsize, "Select the size (in bit units) of the CRC calculation result. The CRC reminder bit size can be any positive integer value from 1 up to 64.")
        CRC_tooltip.SetToolTip(Me.TB_poly, "Enter the key value (the polynomial divisor value) used to process CRC calculation over ""Input String"" data. Use hexadecimal values.")
        CRC_tooltip.SetToolTip(Me.TB_InitRmnd, "Enter the Initial Reminder value. It is important to distinguish one Input String from other string composed by concatenation of one or more ""0"" before the original Input String. Use hexadecimal values.")
        CRC_tooltip.SetToolTip(Me.TB_finalXOr, "Enter the hexadecimal value that will be XOr'ed with the normal CRC result, generating a different output. Use hexadecimal values.")
        CRC_tooltip.SetToolTip(Me.CB_RevInp, "Check this Box to reserve the sequence of bits inside each byte of the ""Input String"" (as used for some communication devices) before start CRC calculation.")
        CRC_tooltip.SetToolTip(Me.CB_RevOut, "Check this Box to reserve the sequence of bits inside the ""CRC Output"" (CRC Remainder).")
        CRC_tooltip.SetToolTip(Me.Button1, "Calculate the CRC of the ""Input String"", according user selected options. CRC (remainder) bit size may be from 1 to 64 bits and the Input String may has odd Length of bits (if ""Offset"" field is also odd).")
        CRC_tooltip.SetToolTip(Me.TB_crc, "The ""CRC Output"" (CRC remainder).")
        CRC_tooltip.SetToolTip(Me.TB_ret, "The ""Return"" parameter gives information about the CRC calculation." & vbCrLf &
                                          "   *) negative values = errors;" & vbCrLf &
                                          "   *) positive values with least significant digit from 0 up to 2 = CRC Size is good(0)/reasonable(1)/low(2) to calculate the CRC of such Input String length - lower values is better;" & vbCrLf &
                                          "   *) positive values with most significant digit equal to 10 = ""Initial Reminder"" is equal to 0, this is not a good approach.")

    End Sub


    Private Sub CB_StrgTpHex_CheckedChanged(sender As Object, e As EventArgs) Handles CB_StrgTpHex.CheckedChanged
        CB_StrgTpASCII.Checked = IIf(CB_StrgTpHex.Checked, False, True)
    End Sub

    Private Sub CB_StrgTpASCII_CheckedChanged(sender As Object, e As EventArgs) Handles CB_StrgTpASCII.CheckedChanged
        CB_StrgTpHex.Checked = IIf(CB_StrgTpASCII.Checked, False, True)
        CB_StrmOrBit.Checked = False
    End Sub

    Private Sub CB_StrmOrBit_CheckedChanged(sender As Object, e As EventArgs) Handles CB_StrmOrBit.CheckedChanged
        Dim aux As Boolean = CB_StrmOrBit.Checked
        NUD_BitOffset.Enabled = aux
        CB_StrmOrByte.Checked = Not aux   'CB_StrmOrByte.Checked = IIf(CB_StrmOrBit.Checked, False, True)
    End Sub

    Private Sub CB_StrmOrByte_CheckedChanged(sender As Object, e As EventArgs) Handles CB_StrmOrByte.CheckedChanged
        Dim aux As Boolean = Not CB_StrmOrByte.Checked
        CB_StrmOrBit.Checked = aux   '  CB_StrmOrBit.Checked = IIf(CB_StrmOrByte.Checked, False, True)
        NUD_BitOffset.Enabled = aux
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim CRCvalue, Poly, FinalXor, Szmask As UInt64
        Dim rtn As Integer
        Dim Strg As String
        Dim StrgBuf = New List(Of Byte)
        Dim StrgPoly = New List(Of Byte)
        Dim k, x, x2, Size As Integer
        Dim offset As UInt64 = 0UL


        '# Read Input String
        Strg = TB_inp.Text
        x = Strg.Length
        If x = 0 Then
            MsgBox("Input String is empty. Fill it with some data.", MsgBoxStyle.Information Or MsgBoxStyle.OkOnly)
            Exit Sub
        End If
        x2 = 0
        If CB_StrgTpHex.Checked Then
            If (x And 1) Then  ' If total amount of hexadecimal digits is NOT multiple of 2 (capable to turn into a complete byte)
                Strg = "0" & Strg     ' Strg.Insert(1, "0")
                offset = IIf(CB_StrmOrBit.Checked, 4UL, 0UL)
                x += 1
                x2 += 1  ' This flag helps to calculate the index position of non Hexadecimal characters in Input String
            End If
        End If
        If CB_StrmOrBit.Checked Then
            offset += CULng(NUD_BitOffset.Value)
        End If
        k = 0
        While k < x
            If CB_StrgTpHex.Checked Then
                If Not Uri.IsHexDigit(Strg(k)) Then
                    MsgBox("Input String has at least one character that can Not be converted to Hexadecimal digits!" &
                           " The first character Is '" & CStr(Strg(k)) & "' at index position " & CStr(k - x2) & ".",
                           MsgBoxStyle.Critical Or MsgBoxStyle.OkOnly)
                    Exit Sub
                ElseIf Not Uri.IsHexDigit(Strg(k + 1)) Then
                    MsgBox("Input String has at least one character that can not be converted to Hexadecimal digits!" &
                           " The first character is: '" & CStr(Strg(k + 1)) & "' at index position " & CStr(k + 1 - x2) & ".",
                           MsgBoxStyle.Critical Or MsgBoxStyle.OkOnly)
                    Exit Sub
                Else
                    StrgBuf.Add(Convert.ToByte(Strg(k) & Strg(k + 1), 16)) 'This method grants that any leading zero will be converted correctly to a Byte.
                    k += 2
                End If
            Else
                StrgBuf.Add(Asc(Strg(k)))
                k += 1
            End If
        End While
        If CB_RevInp.Checked Then  ' Reverse the order of the bits inside each byte of Input String
            If CB_StrmOrByte.Checked OrElse (((x * 8 - offset) And &B111UL) = 0) Then ' Total amount of bits to be analyzed is a multiple of SizeOf(Byte).
                ReverseByteString(StrgBuf)
            Else
                MsgBox("Reversion (reflection) is intended to: byte oriented streams either bit oriented streams with size multiple of 8 bits.")
                Exit Sub
            End If
        End If

        '# Read CRC Size
        Strg = TB_crcsize.Text
        x = Strg.Length
        If x = 0 Then
            MsgBox("CRC size is empty. Fill it with some data.", MsgBoxStyle.Information Or MsgBoxStyle.OkOnly)
            Exit Sub
        End If
        k = 0
        While k < x
            If Not IsNumeric(Strg(k)) Then
                MsgBox("CRC size is must be a number, greater than 0 and less than 64. Fill it with some valid data.", MsgBoxStyle.Information Or MsgBoxStyle.OkOnly)
                Exit Sub
            End If
            k += 1
        End While
        Size = CInt(TB_crcsize.Text)
        If Size <= 0 OrElse Size > 64 Then  ' SizeOf(CRCvalue) is the greater value that CRC Size can achieve, but in this program implementation its size is 64 bit.
            MsgBox("CRC size must be greater than 0 and less than 64. Fill it with some valid data.", MsgBoxStyle.Information Or MsgBoxStyle.OkOnly)
            Exit Sub
        End If
        k = 0
        Szmask = 0UL
        While k < Size
            Szmask = (Szmask << 1) Or &B1UL
            k += 1
        End While

        '# Read Polynomial
        Strg = TB_poly.Text
        k = 0
        x = Strg.Length
        If x = 0 Then
            MsgBox("Polynomial is empty. Fill it with some data.", MsgBoxStyle.Information Or MsgBoxStyle.OkOnly)
            Exit Sub
        End If
        If x And 1 Then
            Strg = "0" & Strg
            x += 1
        End If
        k = 0
        While k < x
            If Not Uri.IsHexDigit(Strg(k)) Then
                MsgBox("Polynomial has at least one character that can not be converted to Hexadecimal digits!" &
                   " The first character is: '" & CStr(Strg(k)) & "' at index position " & CStr(k) & ".",
                   MsgBoxStyle.Critical Or MsgBoxStyle.OkOnly)
                Exit Sub
            End If
            k += 1
        End While
        k = 0
        Poly = 0
        While k < x
            Poly = Poly << 8
            Poly += (Convert.ToByte(Strg(k) & Strg(k + 1), 16))
            k += 2
        End While
        TB_poly.Text = Hex(Poly And Szmask)

        '# Read Initial CRC remainder value
        Strg = TB_InitRmnd.Text
        k = 0
        x = Strg.Length
        If x = 0 Then
            MsgBox("Initial CRC remainder value is empty. Fill it with some data.", MsgBoxStyle.Information Or MsgBoxStyle.OkOnly)
            Exit Sub
        End If
        If x And 1 Then
            Strg = "0" & Strg
            x += 1
        End If
        While k < x
            If Not Uri.IsHexDigit(Strg(k)) Then
                MsgBox("Initial CRC remainder value has at least one character that can not be converted to Hexadecimal digits!" &
                   " The first character is: '" & CStr(Strg(k)) & "' at index position " & CStr(k) & ".",
                   MsgBoxStyle.Critical Or MsgBoxStyle.OkOnly)
                Exit Sub
            End If
            k += 1
        End While
        k = 0
        CRCvalue = 0
        While k < x
            CRCvalue = CRCvalue << 8
            CRCvalue += (Convert.ToByte(Strg(k) & Strg(k + 1), 16))
            k += 2
        End While
        TB_InitRmnd.Text = Hex(CRCvalue And Szmask)

        '# Read Final XOr Value
        Strg = TB_finalXOr.Text
        k = 0
        x = Strg.Length
        If x = 0 Then
            MsgBox("Final XOr Value is empty. Fill it with some data.", MsgBoxStyle.Information Or MsgBoxStyle.OkOnly)
            Exit Sub
        End If
        If x And 1 Then
            Strg = "0" & Strg
            x += 1
        End If
        While k < x
            If Not Uri.IsHexDigit(Strg(k)) Then
                MsgBox("Final XOr Value has at least one character that can not be converted to Hexadecimal digits!" &
                   " The first character is: '" & CStr(Strg(k)) & "' at index position " & CStr(k) & ".",
                   MsgBoxStyle.Critical Or MsgBoxStyle.OkOnly)
                Exit Sub
            End If
            k += 1
        End While
        k = 0
        FinalXor = 0
        While k < x
            FinalXor = FinalXor << 8
            FinalXor += (Convert.ToByte(Strg(k) & Strg(k + 1), 16))
            k += 2
        End While
        TB_finalXOr.Text = Hex(FinalXor And Szmask)

        '# Calculates CRC
        'MsgBox("CRC size: " & CStr(Size) & "; Polynomial: " & CStr(Poly) & "; CRC_init: " & CStr(CRCvalue) & "; Final XOR: " & CStr(FinalXor) & "; offset: " & CStr(offset) & ".")
        rtn = CRCn(StrgBuf.ToArray, CRCvalue, Size, Poly, FinalXor, offset)
        If rtn >= 0 Then
            If CB_RevOut.Checked Then  ' Reverse the order of the bits inside CRC result (Remainder).
                ReverseCRCOut(CRCvalue, Size)
            End If
            TB_crc.Text = Hex(CRCvalue)
        End If
        If (rtn > 0) And (rtn < 10) Then
            MsgBox("Block size is bigger than desired to achieve good performance with actual size of CRC; Or Initial CRC value is zero - a value that should be avoided -.", MsgBoxStyle.OkOnly, "WARNING")
            'ElseIf (rtn > 10) Then
            '    MsgBox("Initial CRC value is zero. This value should be avoided.", MsgBoxStyle.OkOnly, "WARNING")
        End If
        TB_ret.Text = CStr(rtn)

    End Sub


    Private Function CRCn(ByRef buf As Byte(), ByRef CRC As Object, Optional ByVal CrcSz As Byte = 0,
                          Optional ByVal Poly As Object = 0UL, Optional ByVal FinalXOr As Object = 0UL,
                          Optional ByVal Offsetbit As ULong = 0) As Integer

        '#### Este algoritmo esta funcionando corretamente mas ainda carece de analises:
        '##     a) verificacao da melhor compatibilidade entre variaveis e os tipos de dados indicados para as funcoes que realizam no algoritmo;
        '##     b) otimizacoes do proprio algoritmo

        '#### This function calculates the Cyclic Redundancy Check of the bit string in array "buf".
        '##
        '## Parameters:
        '##     "buf" =>  unsigned byte array containing the bit string which the CRC will be calculated; - input -
        '##     "CRC" =>  unsigned integer 32 bits variable that will receive CRC calculation result (remainder); - output -
        '##     "Poly" => its argument must be the same (primitive) data type as "CRC" argument.
        '##     "CrcSz" => value must be equal or lower than the bit size of "CRC" argument (primitive) data type.
        '##     "Offsetbit" => base 0 index of the first bit from bit string "buf" to apply to CRC calculation procedure.
        '##
        '## Return value:
        '##     -1 => the "buf" argument does not reference any array;
        '##     -2 => the array referenced by "buf" is empty (has no item);
        '##     -3 => the "CRC" argument data type is not an allowed data type (unsigned integer);
        '##     -4 => the argument data types of "CRC" and "Poly" are not the same;
        '##     -5 => the bit size of "CRC" argument data type cannot be lower than "CrcSz" value;
        '##     -6 => the bit size of "buf" argument data type avoids the simplification method (using shif instead of division) used in this algorithm. This requires that a few line codes must be changed;
        '##     -7 => the argument data types of "CRC" and "FinalXOr" are not the same;
        '##      0 => the "CrcSz" argument is big enough to allow CRC calculation (over "buf" contents of such bit length) identify changes in: ONE, TWO, THREE, FIVE or any odd number of bits.
        '##      1 => the "CrcSz" argument is big enough to allow CRC calculation (over "buf" contents of such bit length) identify changes only in: ONE either TWO bits.
        '##      2 => the "CrcSz" argument is small to allow CRC calculation over "buf" contents of such bit length. The selected CRC size may cause the CRC calculation miss a bit change (or more) returning the same remainder ("CRC" parameter).
        '##     (10 up to 12) => the initial CRC remainder must be different from 0. This avoids the CRC calculation over bit strings that differs only by leading zeros return the same result (remainder);
        '##                      10 : "CrcSz" is good enough to allow CRC calculation identify changes in any odd number of bits.
        '##                      11 : "CrcSz" is reasonable to allow CRC calculation identify changes only in one or two bits.
        '##                      12 : "CrcSz" is low and CRC calculation may miss a bit change.


        '#### This algorithm results may be checked against http://crccalc.com/ 
        '## If you select "ASCII" option in the internet site's field "Input type:", mark the checkbox "ASCII Character" in this application.
        '## If you select "Hex" option in the internet site's field "Input type:", mark the checkbox "Hexadecimal digits" in this application.
        '## In the site's field "Output type:" alway select "HEX".
        '## The argument of "Poly" must be the value shown in column named "Poly" from http://crccalc.com/ site.
        '## The argument of "FinalXOr" must be in "XorOut" column.
        '## The argument of "CRC" must be 8 for option "Calc CRC-8", must be 16 for "Calc CRC-16" either must be 32 for "Calc CRC-32".
        '## The value shown in collumn named "Init" must be copied to "Initial Reminder" fild of this application.
        '## If column "RefIn" is true, mark the checkbox "Input String (inside bytes)". Otherwise, do NOT mark it.
        '## If column "RefOut" is true, mark the checkbox "Output". Otherwise, do NOT mark it.
        '## If the text inserted in "Input String" textbox has an odd number of characters the site will not process this input string
        '## correctly, because (as you can see by marking "Show processed data(HEX)" in the site) the last character will be converted
        '## to a full octect (8 bits), instead of a nible (4 bits), and the four most significant bits has value zero. So, the processed
        '## data will NOT be what you mean, once the site is designed to work with BYTE orientation only.



        '#### Data Type of "buf" MUST NEVER be greater than "CRC" object Data Type.  
        Dim output As Integer = 0
        Dim CRCbitlen, BufLen As Int32
        Dim DetectThresh1, DetectThresh2, mask As UInt64
        Dim Ix0, Ix1, Ixbufbit0, Ixbufbit1, Ixaux, Ixturn, blocksz, shft, shftzero As Long
        Dim Ixbit0, Ixbit1 As Integer

        Dim aux, DivMask, CRCMask As UInt64    'these variables must has same data type than "CRC" or a data type with greater size (in bits).
        Dim BufDtDiv, BufDtMod, BufMaskAux1 As Byte   'these variables must has same data type than "buf" (primitive).

        Dim BufDtBitLenIx As UInt16 ' Index (0 base) of Most Significant Bit in "buf" (primitive) data type.
        Dim BufDtBitMask As UInt64    ' Bitmask of True values only in "BufDtBitLen" Least Significant Bits. 
        Dim BufDtBitMSBMask As UInt64    ' Bitmask of True value only in "BufDtBitLenIx" bit (base 0 index). 


        '#  Since an "N bit CRC" has a polynomial with "N + 1" terms; since the most significant 
        '#  term of any CRC polynomial is always set to "ONE"; and since the XOR operation of 
        '#  polynomial and bitstream will alway set the correspondent bit of polynomial term 
        '#  (N + 1) in the resultant bitstream to be reset, some simplification may be used
        '#  in calculation process:
        '#     CRC_8 polynomial (divisor) will be represented only by 8 term, which fits a single byte;
        '#     CRC_16 polynomial (divisor) will be represented only by 16 term, which fits a single word;
        '#     and so on...

        '#### Get the LENGTH of data type of "buf" elements:
        Dim BufDtBitLen As UInt16 = System.Runtime.InteropServices.Marshal.SizeOf(buf.GetType().GetElementType()) * 8   ' Length in bits of "buf" (primitive) data type. 
        'Const BufDtBitLen As UInt16 = 8  

        BufDtBitLenIx = BufDtBitLen - 1

        If buf Is Nothing Then
            Return -1
        Else

            '# Find the value that may turn Integer division into shift operations over "buf" (primitive) Data Type
            BufDtMod = BufDtBitLenIx
            BufDtDiv = &H0
            aux = BufDtBitLen
            While ((aux > 0) AndAlso ((aux And &B1) = 0))
                BufDtDiv += 1
                aux = aux >> 1
            End While
            If aux > 1 Then
                Return -6   '# In this algorithm, a few Division and Mod operations are made through bit shifts.
                '# This simplification will return the correct value only if BufDtBitLen is an exponent of 2 (i.e. 2, 4, 8, 16, 32, 64, ...).
                '# If necessary, when BufDtBitLen is any different value (12, 24, 48, 96, 172, etc), the two follow operations:
                '# "(EXPRESSION >> BufDtDiv)"   and the "(EXPRESSION And BufDtMod)"  must be changed to:
                '# "(EXPRESSION / BufDtBitLen)"   and the "(EXPRESSION Mod BufDtBitLen)" , respectively, all along this algorithm. 
            End If

            output = 0
            BufLen = buf.Length
            If BufLen = 0 Then
                Return -2
            Else
                '##  Check if "CRC" object data type is valid.

                If (TypeOf CRC Is Byte) Then
                    CRCbitlen = 8
                    DetectThresh2 = Byte.MaxValue           ' = 2^(8) - 1 = 255    ;  DetectThresh1 =  2^(7) - 1 = 127
                ElseIf (TypeOf CRC Is UShort) OrElse (TypeOf CRC Is UInt16) Then
                    CRCbitlen = 16
                    DetectThresh2 = UShort.MaxValue         ' = 2^(16) - 1 = 65535    ;  DetectThresh1 =  2^(15) - 1 = 32767
                ElseIf (TypeOf CRC Is UInteger) OrElse (TypeOf CRC Is UInt32) Then
                    CRCbitlen = 32
                    DetectThresh2 = UInteger.MaxValue       ' = 2^(32) - 1 = 4294967295    ;  DetectThresh1 =  2^(31) - 1 = 2147483647
                ElseIf (TypeOf CRC Is UInt64) OrElse (TypeOf CRC Is ULong) Then
                    CRCbitlen = 64
                    DetectThresh2 = UInt64.MaxValue         ' = 2^(64) - 1    ;  DetectThresh1 =  2^(63) - 1 =  
                Else
                    Return -3
                End If
                DetectThresh1 = (DetectThresh2 >> 1)    ' = 2^(CRCbitlen - 1) - 1 
                If CRC = 0UL Then  ' To avoid the possibility of additional leading ZERO's return same CRC remainder at end of process. I.E diferent bitstreams (with diferent sizes) generating same CRC value. 
                    output += 10
                End If

                '##  Check if "Poly" object data type is equal to "CRC" (primitive) data type.
                If (TypeOf Poly Is Byte) Then
                    If CRCbitlen <> 8 Then
                        Return -4
                    Else
                        If Poly = 0 Then
                            Poly = &H2FUS ' CRC-8-OpenSafety
                            'Private Const CRC8PolyOS As Byte = &B0010_1111UI  'As defined by OpenSafety CRC8PolyOS = &B1_0010_1111UI, but here it is used a simplification that implies at exclude most significant term.
                        End If
                    End If
                ElseIf (TypeOf Poly Is UShort) OrElse (TypeOf Poly Is UInt16) Then
                    If CRCbitlen <> 16 Then
                        Return -4
                    Else
                        If Poly = 0 Then
                            Poly = &H1021US ' CRC-16-CCITT Polynomial
                        End If
                    End If
                ElseIf (TypeOf Poly Is UInteger) OrElse (TypeOf Poly Is UInt32) Then
                    If CRCbitlen <> 32 Then
                        Return -4
                    Else
                        If Poly = 0 Then
                            Poly = &H1EDC6F41UI ' CRC-32-C (Castagnoli) Polynomial
                        End If
                    End If
                ElseIf (TypeOf Poly Is ULong) OrElse (TypeOf Poly Is UInt64) Then
                    If CRCbitlen <> 64 Then
                        Return -4
                    Else
                        If Poly = 0 Then
                            Poly = &H42F0E1EBA9EA3693UL ' CRC-64-ECMA (Castagnoli) Polynomial
                        End If
                    End If
                Else
                    Return -4
                End If

                '##  Check if "FinalXOr" object data type is equal to "CRC" (primitive) data type.
                If (TypeOf FinalXOr Is Byte) Then
                    If CRCbitlen <> 8 Then
                        Return -7
                    End If
                ElseIf (TypeOf FinalXOr Is UShort) OrElse (TypeOf FinalXOr Is UInt16) Then
                    If CRCbitlen <> 16 Then
                        Return -7
                    End If
                ElseIf (TypeOf FinalXOr Is UInteger) OrElse (TypeOf FinalXOr Is UInt32) Then
                    If CRCbitlen <> 32 Then
                        Return -7
                    End If
                ElseIf (TypeOf FinalXOr Is ULong) OrElse (TypeOf FinalXOr Is UInt64) Then
                    If CRCbitlen <> 64 Then
                        Return -7
                    End If
                Else
                    Return -7
                End If

                '# Check if "CrcSz" is valid (less or equal "bitlen") and clear polynomial term above CrcSz value 
                If CrcSz > CRCbitlen Then
                    Return -5
                ElseIf CrcSz = 0 Then
                    CrcSz = CRCbitlen
                End If

                '#  Creates a binary mask for "Poly", with least significant bits (in a number equal to CrcSz value) set to True.
                Ixturn = 1
                mask = &B1UL
                While Ixturn < CrcSz
                    mask = (mask << 1) Or &B1UL
                    Ixturn += 1
                End While
                Poly = Poly And mask  ' Clear polynomial terms above CrcSz value, i.e. clear most signifcant bits. If CrcSz is 3, only 3 least significant bits will be left as original values, all others will be cleared.

                '## Check the performance of selected CRC Size to identify bit changes in a bit string of such length as in "buf".
                blocksz = BufLen * BufDtBitLen - Offsetbit  ' Total number of bits in "buf" .   => blocksz = buflen * SizeOf("buf" primitive data type)
                If blocksz > DetectThresh2 Then    ' The selected (low) CRC Size implies, to any Input String with such length, in a low CRC performance to detect a change in original Input String.
                    output += 2
                ElseIf blocksz > DetectThresh1 Then  ' The selected CRC Size implies, to any Input String with such length, in a medium CRC performance to detect a change in original Input String.
                    output += 1
                End If
            End If
        End If


        '# Creates a bitmask for "buf" (primitive) Data Type. Allowed values: any integer from 1 up to 64 bits. 
        BufDtBitMask = &H0UL
        aux = BufDtBitLen
        If aux >= 64 Then
            BufDtBitMask = &HFFFF_FFFF_FFFF_FFFFUL
            aux -= 64
        End If
        If aux >= 32 Then
            BufDtBitMask = (BufDtBitMask << 32) Or &HFFFF_FFFFUL
            aux -= 32
        End If
        If aux >= 16 Then
            BufDtBitMask = (BufDtBitMask << 16) Or &HFFFFUL
            aux -= 16
        End If
        If aux >= 8 Then
            BufDtBitMask = (BufDtBitMask << 8) Or &HFFUL
            aux -= 8
        End If
        While aux > 0
            BufDtBitMask = (BufDtBitMask << 1) Or &B1UL
            aux -= 1
        End While

        '# Creates a bitmask for "N" Least Significant Bits of CRC_N (primitive) Data Type
        aux = CrcSz
        CRCMask = &H0UL
        If aux >= 64 Then
            CRCMask = &HFFFF_FFFF_FFFF_FFFFUL
            aux -= 64
        End If
        If aux >= 32 Then
            CRCMask = (CRCMask << 32) Or &HFFFF_FFFFUL
            aux -= 32
        End If
        If aux >= 16 Then
            CRCMask = (CRCMask << 16) Or &HFFFFUL
            aux -= 16
        End If
        If aux >= 8 Then
            CRCMask = (CRCMask << 8) Or &HFFUL
            aux -= 8
        End If
        While aux
            CRCMask = (CRCMask << 1) Or &B1UL
            aux -= 1
        End While

        '# Creates a "last bit index" bitmask for DivMask (for CRC calculation)
        DivMask = (CRCMask >> 1) Xor CRCMask

        '# Creates a "last bit index" bitmask for "buf" (primitive) data type. 
        BufDtBitMSBMask = (BufDtBitMask >> 1) Xor BufDtBitMask

        CRC = CRC And CRCMask ' Clear most significant bits of Initial value of CRC, above CRC size.
        FinalXOr = FinalXOr And CRCMask  ' Clear most significant bits of FinalXOr, above CRC size.

        '# Set initial values of bitstream indexs and "buf" elements.
        Ixbufbit0 = Offsetbit ' Base 0 Index for actual bit (from "buf" bitstream) in each loop of CRC (remainder) calculation. Count start from byte 0 to higher bytes and, inside each byte, from MSB to LSB) . 
        Ixbufbit1 = BufLen * BufDtBitLen - 1  ' Index value of the last bit in "buf" bitstream (Least Significant Bit of last byte)
        Ix0 = Ixbufbit0 >> BufDtDiv  ' Ix0 = Ixbufbit0 / BufDtBitLen  ' Index of "buf" element where is located the first bit to be loaded in CRC remainder, in each loop.
        Ix1 = (Ixbufbit0 + CrcSz - 1) >> BufDtDiv   ' Ix1 += (Ixbufbit0 + CrcSz - 1) / BufDtBitLen ' Index of "buf" element where is located the last bit to be loaded in CRC remainder, in each loop.
        Ixbit0 = BufDtBitLenIx - (Ixbufbit0 And BufDtMod)    ' Ixbit0 = (BufDtBitLen - 1) - (Ixbufbit0 Mod BufDtBitLen)  ' Base 0 Index of first bit, located in "buf(Ix0)", to be loaded in CRC remainder, where the LSB of "buf(Ix0)" byte is index 0.
        Ixbit1 = BufDtBitLenIx - ((Ixbufbit0 + CrcSz - 1) And BufDtMod)    ' Ixbit1 = (BufDtBitLen - 1) - ((Ixbufbit0 + CrcSz - 1) Mod BufDtBitLen)   ' Base 0 Index of last bit, located in "buf(Ix1)", to be loaded in CRC remainder, where the LSB of "buf(Ix0)" byte is index 0.
        BufMaskAux1 = &B1 << Ixbit1
        shftzero = 0   ' Number of consecutive times that a bit "0" has been aligned to the greater term (N+1) of CRC_N polynomial in remainder calculation.

        '# Load first set of "CrcSz" bits from bitstream into "CRC"
        aux = buf(Ix0) ' Loads, in CRC, bits from first element of "buf" (where is found the first bit of bitstream that must be processed).
        aux = aux And (BufDtBitMask >> (BufDtBitLenIx - Ixbit0))   ' Clear Most Significant BitS of "buf(Ix0)" that should not be loaded in "CRC" remainder. 

        shft = Ixbit0 - (CrcSz - 1)
        If shft > 0 Then
            aux = (aux >> shft)   ' aux = (aux >> shft) And CRCMask
        ElseIf shft < 0 Then
            shft = -shft   ' Now "Ixaux"'s value  is positive and means the amount of bits required to be loaded in "CRC" remainder, after bits in "buf(Ix0)".
            If Ix0 = Ix1 Then
                aux = aux >> Ixbit1
            Else   ' Ix0 < Ix1
                Ixaux = Ix0 + 1
                While (Ixaux < Ix1)    ' Loads its of intermediate elements of "buf".
                    aux = (aux << BufDtBitLen)
                    If Ixaux < BufLen Then
                        aux = aux Or buf(Ixaux)
                    End If
                    Ixaux += 1
                End While
                aux = aux << (BufDtBitLen - Ixbit1)
                If Ix1 < BufLen Then
                    aux = aux Or (buf(Ix1) >> Ixbit1)
                End If
            End If
            'Else,  If shft = 0, it means that "CRC" already has loaded the first bits from (original) bitstream values .
        End If

        CRC = CRC Xor aux


        '# Start CRC calculation procedure:
        '#     For each bit selected in "buf" bitstream:
        '#       a) check if the selected Bit is True;
        '#       b) if selected Bit (in bitstream) is True:
        '#          b.01) Calculates the indexes of next bits (from original "buf" bitstream) that will be loaded in Least Significant Bits of CRC remainder.
        '#          b.02) Left Shifts CRC remainder.
        '#          b.03) Loads next bits (from original "buf" bitstream) in Least Significant Bits of CRC remainder.
        '#       c) if selected Bit (in bitstream) is false
        '#          c.01) Left Shifts CRC remainder.

        While Ixbufbit0 <= Ixbufbit1
            If ((CRC And DivMask) > 0) Then   '  Check if MSB of remainder is True (to compute next intermediate remainder, "after shift one bit") or False (to just shift one bit and check MSB of the CRC remainder again without compute any intermediate remainder).
                '# Shifts the CRC remainder and concatenates with next (not XORed) bits of original "buf" bitstream.
                If shftzero = 0 Then
                    '# Update "buf" index ("Ix1") and bit mask ("mask1") for the last bit, from "buf" bitstream, to be include in Least Significant Bit of CRC (remider).
                    Ixbit1 -= 1
                    If Ixbit1 < 0 Then
                        Ixbit1 = BufDtBitLenIx
                        Ix1 += 1
                        BufMaskAux1 = BufDtBitMSBMask ' mask1 = value with size equals to SizeOf("buf" primitive data type) and only its Most Significant Bit is set to True. 
                    Else
                        BufMaskAux1 = BufMaskAux1 >> 1
                    End If
                    '# Shift one bit in CRC remainder (and include next bit from original bitstream in LSB of CRC remainder) .
                    CRC = (CRC << 1)   ' CRC = (CRC << 1) And (Not &B1UL)
                    If (Ix1 < BufLen) AndAlso (buf(Ix1) And BufMaskAux1) <> 0 Then
                        CRC = CRC Or &H1UL
                    End If
                Else        'ElseIf (shftzero > 0) AndAlso shftzero < (CrcSz - 1) Then
                    shft = Ixbit1 - (shftzero + 1) ' Amount of bits that must be shifted to put in "aux" only the bits necessary (missed) to fill "CRC" remainder, and also possible bits that were already laded. 
                    Ix0 = Ix1
                    Ixbit0 = Ixbit1 - 1
                    If Ixbit0 < 0 Then
                        Ix0 += 1
                        Ixbit0 = BufDtBitLenIx
                    End If
                    If Ix0 < BufLen Then
                        aux = buf(Ix0) And (BufDtBitMask >> (BufDtBitLenIx - Ixbit0))    ' aux = buf(Ix0) And (BufDtBitMask >> (BufDtBitLenIx - Ixbit0))    ' Clear Most Significant BitS of "buf(Ix0)" that had already been loaded in "CRC" remainder. 
                        If shft >= 0 Then  ' All bits (from bit stream) that must be loaded in "CRC" remainder is in same "buf(Ix0)" element. 
                            aux = aux >> shft
                            Ixbit1 = shft ' This update is necessary to next loop. And Ix1 does not change its value.
                            ' Ix1 keeps its same value.
                        Else    ' A few bits (from bit stream) that must be loaded in "CRC" remainder is NOT only in "buf" element where the last bit loaded in previous loop interation ("Ixbit1" last iteration) was. 
                            shft = -shft   ' Now "Ixaux"'s value  is positive and means the amount of bits required to be loaded in "CRC" remainder, after bits in "buf(Ix0)".
                            Ix1 += 1 + ((shft - 1) >> BufDtDiv)   ' Ix1 += 1 + ((Ixaux - 1) / BufDtBitLen)
                            Ixbit1 = (BufDtBitLenIx - ((shft - 1) And BufDtMod))    ' Ixbit1 = BufDtBitLenIx - ((Ixaux - 1) Mod BufDtBitLen)
                            If Ix0 = Ix1 Then
                                aux = aux >> Ixbit1
                            Else   ' Ix0 < Ix1
                                Ixaux = Ix0 + 1
                                While (Ixaux < Ix1)    ' Loads its of intermediate elements of "buf".
                                    aux = (aux << BufDtBitLen)
                                    If Ixaux < BufLen Then
                                        aux = aux Or buf(Ixaux)
                                    End If
                                    Ixaux += 1
                                End While
                                aux = aux << (BufDtBitLen - Ixbit1)
                                If Ix1 < BufLen Then
                                    aux = aux Or (buf(Ix1) >> Ixbit1)
                                End If
                            End If
                        End If
                    Else
                        aux = &H0UL
                    End If
                    CRC = (CRC << 1)   ' CRC = (CRC << 1) And (Not &B1UL)
                    CRC = CRC Or aux
                    BufMaskAux1 = &B1UL << Ixbit1  '"BufMaskAux1" is necessary only in case when "shftzero = 0", but it needs to be updated in other cases.
                End If
                '# Calculate new remainder.
                CRC = CRC Xor Poly
                '# Set flag vaiables to next loop
                shftzero = 0
            Else
                If shftzero >= (CrcSz - 1) Then  ' The content in "CRC" remainder must be loaded with new data from bitstream to be able to continue the calculation process.
                    shft = Ixbit1 - (shftzero + 1) ' Amount of bits that must be shifted to put in "aux" only the bits necessary (missed) to fill "CRC" remainder, and also possible bits that were already laded. 
                    Ix0 = Ix1
                    Ixbit0 = Ixbit1 - 1
                    If Ixbit0 < 0 Then
                        Ix0 += 1
                        Ixbit0 = BufDtBitLenIx
                    End If
                    If Ix0 < BufLen Then
                        aux = buf(Ix0) And (BufDtBitMask >> (BufDtBitLenIx - Ixbit0))    ' aux = buf(Ix0) And (BufDtBitMask >> (BufDtBitLenIx - Ixbit0))    ' Clear Most Significant BitS of "buf(Ix0)" that had already been loaded in "CRC" remainder. 
                        If shft >= 0 Then  ' All bits (from bit stream) that must be loaded in "CRC" remainder is in same "buf(Ix0)" element. 
                            aux = aux >> shft
                            Ixbit1 = shft ' This update is necessary to next loop. And Ix1 does not change its value.
                            ' Ix1 keeps its same value.
                        Else    ' A few bits (from bit stream) that must be loaded in "CRC" remainder is NOT only in "buf" element where the last bit loaded in previous loop interation ("Ixbit1" last iteration) was. 
                            shft = -shft   ' Now "Ixaux"'s value  is positive and means the amount of bits required to be loaded in "CRC" remainder, after bits in "buf(Ix0)".
                            Ix1 += 1 + ((shft - 1) >> BufDtDiv)   ' Ix1 += 1 + ((Ixaux - 1) / BufDtBitLen)
                            Ixbit1 = (BufDtBitLenIx - ((shft - 1) And BufDtMod))    ' Ixbit1 = BufDtBitLenIx - ((Ixaux - 1) Mod BufDtBitLen)
                            If Ix0 = Ix1 Then
                                aux = aux >> Ixbit1
                            Else   ' Ix0 < Ix1
                                Ixaux = Ix0 + 1
                                While (Ixaux < Ix1)    ' Loads its of intermediate elements of "buf".
                                    aux = (aux << BufDtBitLen)
                                    If Ixaux < BufLen Then
                                        aux = aux Or buf(Ixaux)
                                    End If
                                    Ixaux += 1
                                End While
                                aux = aux << (BufDtBitLen - Ixbit1)
                                If Ix1 < BufLen Then
                                    aux = aux Or (buf(Ix1) >> Ixbit1)
                                End If
                            End If
                        End If
                    Else
                        aux = &H0UL
                    End If
                    CRC = (CRC << 1)   ' CRC = (CRC << 1) And (Not &B1UL)
                    CRC = CRC Or aux
                    BufMaskAux1 = &B1UL << Ixbit1  '"BufMaskAux1" is necessary only in case when "shftzero = 0", but it needs to be updated in other cases.
                    shftzero = 0
                Else
                    '# Set flag vaiables to next loop
                    shftzero += 1
                    CRC = CRC << 1
                End If
            End If
            Ixbufbit0 += 1
        End While
        CRC = (CRC And CRCMask) Xor FinalXOr

        Return output
    End Function



    Private Sub ReverseByteString(ByRef Strg As List(Of Byte), Optional ByVal Offset As Long = 0L,
                                       Optional ByVal Stopbyte As Long = Long.MaxValue)
        '#### This function reverse the bit order inside each "Strg" item (without change the item order).
        '##
        '## Parameters:
        '##     "Strg" =>  list of unsigned byte containing the bit string that will be reversed inside each item; - input -
        '##     "Offset" =>  positive integer value of the (base 0) index from the FIRST "Strg" item that will be reversed; - input -
        '##     "Stopbyte" =>   positive integer value of the (base 0) index from the LAST "Strg" item that will be reversed; - input -
        '##

        Dim BitMask, ScanByte, Revaux As Byte
        Dim m, k As Long

        Dim DataBitLen As UInt16 = System.Runtime.InteropServices.Marshal.SizeOf(Strg.ToArray().GetType().GetElementType()) * 8   ' Length in bits of "Strg" (primitive) data type.  Expression "Strg(0).GetType()" only can be used if "Strg" is not empty. 


        If Stopbyte = Long.MaxValue Then
            Stopbyte = Strg.Count - 1
        End If
        For k = Offset To Stopbyte
            BitMask = &B1UL
            ScanByte = Strg(k)
            Revaux = &B0UL
            '# Reverse bit order inside a byte
            For m = 0 To DataBitLen - 1
                Revaux = Revaux << 1
                If (ScanByte And BitMask) <> 0 Then
                    Revaux = Revaux Xor &B1UL
                End If
                BitMask = BitMask << 1
            Next
            Strg(k) = Revaux
        Next
    End Sub

    Private Sub ReverseCRCOut(ByRef Crc As UInt64, ByVal Sz As UInt16)
        '#### This function reverse the bit order among the "Sz" least significant bits of "Crc" variable.
        '##
        '## Parameters:
        '##     "Crc" =>  unsigned integer containing the bit string that will be reversed; - input -
        '##     "Sz"  =>  unsigned integer containing the number of (least significant) bits in "Crc" that will be reversed; - input -

        Dim BitMask, Revaux As UInt64
        Dim m As Long

        Sz -= 1   'Convert the amount of bits in CRC to (base zero) index of last bit (MSB) of Crc.
        BitMask = &B1UL
        Revaux = &B0UL
        For m = 0 To Sz
            Revaux = Revaux << 1
            If (Crc And BitMask) <> 0 Then
                Revaux = Revaux Xor &B1UL
            End If
            BitMask = BitMask << 1
        Next
        Crc = Revaux
    End Sub

#Region "Microsoft_Fast_CRC_32_w_table"
    Private Function CRC_32(ByRef buf As Byte(), ByRef CRC As UInt32) As Integer
        '#### This function requires the table (array) "CRC32Table" to proccess the CRC 32 bit remainder of "buf" bitstring.
        '## Microsoft exposes this algorithm at site https://msdn.microsoft.com/en-us/library/dd905031.aspx
        '## Unfortunatelly, there is no information about the Polinomial used by this algorithm.
        '## Parameters:
        '##     "buf" =>  unsigned byte array containing the bit string to proccess its CRC; - input -
        '##     "CRC" =>  unsigned integer 32 bits that will store the CRC result (remainder); - output -

        '## Return value:
        '##     -1 => "buf" argument does not reference a valid object;
        '##     -2 => the array referenced by "buf" is empty;
        '##      0 => the "buf" (bit) length is small enough to allow CRC calculation to identify changes in: ONE, TWO, THREE, FIVE or any odd number of bits.
        '##      1 => the "buf" (bit) length is enough to allow CRC calculation to identify changes only in: ONE either TWO bits.
        '##      2 => the "buf" (bit) length is too big to allow CRC calculation. This may cause the CRC calculation to miss a bit change (or more) returning the same remainder ("CRC" parameter) for different strings.

        Dim output As Integer = 0
        Dim index, buflen As Int32

        If buf Is Nothing Then
            Return -1
        Else
            buflen = buf.Length
            If buflen = 0 Then
                Return -2
            ElseIf buflen * 32 > UInt32.MaxValue - 1 Then
                output = 2
            ElseIf buflen * 32 > (UInt32.MaxValue >> 1) - 1 Then
                output = 1
            End If

        End If

        CRC = &HFFFF_FFFFUI
        index = 0
        While (index < buflen)
            CRC = CRC32Table((CRC And &HFFUI) Xor buf(index)) Xor (CRC >> 8)
            index += 1
        End While

        CRC = (CRC Xor &HFFFF_FFFFUI)

        Return output

    End Function

    Private CRC32Table As UInt32() = {
     &H0UI, &H77073096UI, &HEE0E612CUI, &H990951BAUI,
     &H76DC419UI, &H706AF48FUI, &HE963A535UI, &H9E6495A3UI,
     &HEDB8832UI, &H79DCB8A4UI, &HE0D5E91EUI, &H97D2D988UI,
     &H9B64C2BUI, &H7EB17CBDUI, &HE7B82D07UI, &H90BF1D91UI,
     &H1DB71064UI, &H6AB020F2UI, &HF3B97148UI, &H84BE41DEUI,
     &H1ADAD47DUI, &H6DDDE4EBUI, &HF4D4B551UI, &H83D385C7UI,
     &H136C9856UI, &H646BA8C0UI, &HFD62F97AUI, &H8A65C9ECUI,
     &H14015C4FUI, &H63066CD9UI, &HFA0F3D63UI, &H8D080DF5UI,
     &H3B6E20C8UI, &H4C69105EUI, &HD56041E4UI, &HA2677172UI,
     &H3C03E4D1UI, &H4B04D447UI, &HD20D85FDUI, &HA50AB56BUI,
     &H35B5A8FAUI, &H42B2986CUI, &HDBBBC9D6UI, &HACBCF940UI,
     &H32D86CE3UI, &H45DF5C75UI, &HDCD60DCFUI, &HABD13D59UI,
     &H26D930ACUI, &H51DE003AUI, &HC8D75180UI, &HBFD06116UI,
     &H21B4F4B5UI, &H56B3C423UI, &HCFBA9599UI, &HB8BDA50FUI,
     &H2802B89EUI, &H5F058808UI, &HC60CD9B2UI, &HB10BE924UI,
     &H2F6F7C87UI, &H58684C11UI, &HC1611DABUI, &HB6662D3DUI,
     &H76DC4190UI, &H1DB7106UI, &H98D220BCUI, &HEFD5102AUI,
     &H71B18589UI, &H6B6B51FUI, &H9FBFE4A5UI, &HE8B8D433UI,
     &H7807C9A2UI, &HF00F934UI, &H9609A88EUI, &HE10E9818UI,
     &H7F6A0DBBUI, &H86D3D2DUI, &H91646C97UI, &HE6635C01UI,
     &H6B6B51F4UI, &H1C6C6162UI, &H856530D8UI, &HF262004EUI,
     &H6C0695EDUI, &H1B01A57BUI, &H8208F4C1UI, &HF50FC457UI,
     &H65B0D9C6UI, &H12B7E950UI, &H8BBEB8EAUI, &HFCB9887CUI,
     &H62DD1DDFUI, &H15DA2D49UI, &H8CD37CF3UI, &HFBD44C65UI,
     &H4DB26158UI, &H3AB551CEUI, &HA3BC0074UI, &HD4BB30E2UI,
     &H4ADFA541UI, &H3DD895D7UI, &HA4D1C46DUI, &HD3D6F4FBUI,
     &H4369E96AUI, &H346ED9FCUI, &HAD678846UI, &HDA60B8D0UI,
     &H44042D73UI, &H33031DE5UI, &HAA0A4C5FUI, &HDD0D7CC9UI,
     &H5005713CUI, &H270241AAUI, &HBE0B1010UI, &HC90C2086UI,
     &H5768B525UI, &H206F85B3UI, &HB966D409UI, &HCE61E49FUI,
     &H5EDEF90EUI, &H29D9C998UI, &HB0D09822UI, &HC7D7A8B4UI,
     &H59B33D17UI, &H2EB40D81UI, &HB7BD5C3BUI, &HC0BA6CADUI,
     &HEDB88320UI, &H9ABFB3B6UI, &H3B6E20CUI, &H74B1D29AUI,
     &HEAD54739UI, &H9DD277AFUI, &H4DB2615UI, &H73DC1683UI,
     &HE3630B12UI, &H94643B84UI, &HD6D6A3EUI, &H7A6A5AA8UI,
     &HE40ECF0BUI, &H9309FF9DUI, &HA00AE27UI, &H7D079EB1UI,
     &HF00F9344UI, &H8708A3D2UI, &H1E01F268UI, &H6906C2FEUI,
     &HF762575DUI, &H806567CBUI, &H196C3671UI, &H6E6B06E7UI,
     &HFED41B76UI, &H89D32BE0UI, &H10DA7A5AUI, &H67DD4ACCUI,
     &HF9B9DF6FUI, &H8EBEEFF9UI, &H17B7BE43UI, &H60B08ED5UI,
     &HD6D6A3E8UI, &HA1D1937EUI, &H38D8C2C4UI, &H4FDFF252UI,
     &HD1BB67F1UI, &HA6BC5767UI, &H3FB506DDUI, &H48B2364BUI,
     &HD80D2BDAUI, &HAF0A1B4CUI, &H36034AF6UI, &H41047A60UI,
     &HDF60EFC3UI, &HA867DF55UI, &H316E8EEFUI, &H4669BE79UI,
     &HCB61B38CUI, &HBC66831AUI, &H256FD2A0UI, &H5268E236UI,
     &HCC0C7795UI, &HBB0B4703UI, &H220216B9UI, &H5505262FUI,
     &HC5BA3BBEUI, &HB2BD0B28UI, &H2BB45A92UI, &H5CB36A04UI,
     &HC2D7FFA7UI, &HB5D0CF31UI, &H2CD99E8BUI, &H5BDEAE1DUI,
     &H9B64C2B0UI, &HEC63F226UI, &H756AA39CUI, &H26D930AUI,
     &H9C0906A9UI, &HEB0E363FUI, &H72076785UI, &H5005713UI,
     &H95BF4A82UI, &HE2B87A14UI, &H7BB12BAEUI, &HCB61B38UI,
     &H92D28E9BUI, &HE5D5BE0DUI, &H7CDCEFB7UI, &HBDBDF21UI,
     &H86D3D2D4UI, &HF1D4E242UI, &H68DDB3F8UI, &H1FDA836EUI,
     &H81BE16CDUI, &HF6B9265BUI, &H6FB077E1UI, &H18B74777UI,
     &H88085AE6UI, &HFF0F6A70UI, &H66063BCAUI, &H11010B5CUI,
     &H8F659EFFUI, &HF862AE69UI, &H616BFFD3UI, &H166CCF45UI,
     &HA00AE278UI, &HD70DD2EEUI, &H4E048354UI, &H3903B3C2UI,
     &HA7672661UI, &HD06016F7UI, &H4969474DUI, &H3E6E77DBUI,
     &HAED16A4AUI, &HD9D65ADCUI, &H40DF0B66UI, &H37D83BF0UI,
     &HA9BCAE53UI, &HDEBB9EC5UI, &H47B2CF7FUI, &H30B5FFE9UI,
     &HBDBDF21CUI, &HCABAC28AUI, &H53B39330UI, &H24B4A3A6UI,
     &HBAD03605UI, &HCDD70693UI, &H54DE5729UI, &H23D967BFUI,
     &HB3667A2EUI, &HC4614AB8UI, &H5D681B02UI, &H2A6F2B94UI,
     &HB40BBE37UI, &HC30C8EA1UI, &H5A05DF1BUI, &H2D02EF8D
    }

#End Region

End Class



